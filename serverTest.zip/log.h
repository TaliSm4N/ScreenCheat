#ifndef LOG_H
#define LOG_H

#include <stdio.h>
#include <stdlib.h>

void error_handling(char *);
void Log(char *);
void LogNum(char *,int);

#endif
