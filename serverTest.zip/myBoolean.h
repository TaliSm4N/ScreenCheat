#ifndef MY_BOOLEAN_H
#define MY_BOOLEAN_H

#define TRUE 1
#define FALSE 0

#endif
