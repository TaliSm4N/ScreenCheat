#ifndef LOCATION_H
#define LOCATION_H

typedef struct location
{
	float x;
	float y;
	float z;
}loc;

#endif
