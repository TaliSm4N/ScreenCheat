#ifndef INFO_H
#define INFO_H

struct gameInfo
{
	int kill;
	int death;
	int win;
};

#endif
